# Expense Tracker — CI/CD with Jenkins, Docker & Terraform

A personal **Expense Tracker** web app with a complete end-to-end CI/CD pipeline
built using **Jenkins** as the core focus, containerized with **Docker**,
deployed to **AWS EC2** provisioned via **Terraform**, and monitored
with **Prometheus + Grafana**.

---

## Tech Stack

| Layer          | Technology                             |
|---------------|----------------------------------------|
| Backend        | Java 17, Spring Boot 3.2, PostgreSQL   |
| Frontend       | React 18, Recharts (charts)            |
| CI/CD          | **Jenkins** — 8-stage Jenkinsfile      |
| Containers     | Docker, Docker Compose                 |
| Infrastructure | Terraform → AWS EC2                    |
| Monitoring     | Prometheus, Grafana                    |

---

## App Features

- Add, edit, delete expenses with categories (Food, Transport, Shopping, etc.)
- Multiple payment methods: Cash, Card, UPI, Net Banking
- Set monthly budgets per category with **budget vs actual progress bars**
- Dashboard: pie chart (spending by category) + recent expenses list
- Analytics page: bar chart by category for the current month
- Sample data pre-loaded on first run

---

## Architecture

```
GitHub Push
    |
    v
Jenkins (on EC2 :8080)
    |
    |-- [1] Checkout code
    |-- [2] Unit Tests (Mockito) --> JUnit report in Jenkins UI
    |-- [3] Build JAR (Maven)
    |-- [4] Build Frontend (npm)
    |-- [5] Docker Build (2 images)
    |-- [6] Docker Push --> Docker Hub
    |-- [7] SSH Deploy --> EC2 docker-compose up
    +-- [8] Health Check --> /actuator/health

EC2 Instance (Terraform provisioned)
    |-- expense-backend   :8080
    |-- expense-frontend  :3000
    |-- postgres          :5432
    |-- prometheus        :9090
    +-- grafana           :3001
```

---

## Quick Start (Local Docker)

```bash
git clone https://github.com/yourusername/expense-tracker-cicd
cd expense-tracker-cicd

# Start everything with Docker Compose
docker-compose up --build -d

# Access the app
# Frontend:   http://localhost:3000
# API:        http://localhost:8080/api/expenses
# Prometheus: http://localhost:9090
# Grafana:    http://localhost:3001  (admin / admin123)
```

---

## Deploy to AWS with Terraform

```bash
cd terraform

# 1. Initialize
terraform init

# 2. Preview
terraform plan

# 3. Provision EC2 (auto-installs Docker, Jenkins, Java)
terraform apply

# Output:
# ec2_public_ip = "x.x.x.x"
# jenkins_url   = "http://x.x.x.x:8080"
# app_url       = "http://x.x.x.x:3000"
# grafana_url   = "http://x.x.x.x:3001"
```

Terraform creates:
- VPC + Public Subnet + Internet Gateway + Route Table
- Security Group (ports: 22, 3000, 3001, 8080, 9090)
- EC2 t3.medium (Ubuntu 22.04, 20GB gp3)
- **User-data bootstraps Docker, Docker Compose, Java 17, and Jenkins automatically** — reduces manual setup time by ~60%

---

## Jenkins CI/CD Setup

Full guide: `jenkins/jenkins-setup.md`

### Required Jenkins Credentials

| ID                       | Type             | Description             |
|--------------------------|------------------|-------------------------|
| `docker-hub-credentials` | Username/Password| Docker Hub account      |
| `ec2-host`               | Secret Text      | EC2 public IP           |
| `ec2-ssh-key`            | SSH private key  | Your EC2 .pem key       |

### The 8-Stage Pipeline (Jenkinsfile)

```
Stage 1: Checkout       → git pull
Stage 2: Unit Tests     → mvn test + JUnit report
Stage 3: Build JAR      → mvn clean package
Stage 4: Build Frontend → npm ci + npm build
Stage 5: Docker Build   → 2 images (backend + frontend)
Stage 6: Docker Push    → push to Docker Hub (tagged with BUILD_NUMBER)
Stage 7: Deploy EC2     → SSH + docker-compose up -d
Stage 8: Health Check   → curl /actuator/health (retries 5x)
```

---

## API Endpoints

| Method | Endpoint                           | Description              |
|--------|------------------------------------|--------------------------|
| GET    | /api/expenses                      | All expenses             |
| POST   | /api/expenses                      | Create expense           |
| PUT    | /api/expenses/{id}                 | Update expense           |
| DELETE | /api/expenses/{id}                 | Delete expense           |
| GET    | /api/expenses/search?keyword=X     | Search by title          |
| GET    | /api/expenses/dashboard            | Dashboard stats          |
| GET    | /api/expenses/summary?year=&month= | Monthly summary          |
| POST   | /api/budgets                       | Set monthly budget       |
| GET    | /api/budgets/vs-actual?month=&year=| Budget vs actual         |

---

## Monitoring

Grafana: `http://<EC2_IP>:3001` — login: `admin / admin123`

Import dashboards from grafana.com:
- **4701** → JVM Micrometer (CPU, Memory, GC, Threads)
- **11378** → Spring Boot HTTP metrics (request rate, error rate, response time)

Prometheus scrapes `/actuator/prometheus` every 10 seconds.

---

## Project Structure

```
expense-tracker-cicd/
├── backend/                          # Spring Boot REST API
│   ├── src/main/java/com/expense/
│   │   ├── controller/               # ExpenseController, BudgetController
│   │   ├── service/                  # Business logic + analytics
│   │   ├── repository/               # JPA + custom JPQL queries
│   │   ├── model/                    # Expense, Budget entities
│   │   └── config/                   # Sample data initializer
│   └── Dockerfile
├── frontend/                         # React 18 SPA
│   ├── src/pages/                    # Dashboard, Expenses, Budget, Analytics
│   ├── src/services/api.js           # Axios API layer
│   └── Dockerfile
├── jenkins/
│   ├── Jenkinsfile                   # 8-stage CI/CD pipeline (MAIN FOCUS)
│   └── jenkins-setup.md             # Step-by-step Jenkins guide
├── terraform/
│   ├── main.tf                       # VPC, EC2, Security Group
│   ├── userdata.sh                   # Bootstrap script (Docker + Jenkins)
│   ├── variables.tf
│   └── outputs.tf
├── monitoring/
│   ├── prometheus/prometheus.yml
│   └── grafana/datasource.yml
├── docker-compose.yml                # Local + production orchestration
├── .env.example
└── README.md
```

---

## Interview Talking Points

**"Walk me through your Jenkins pipeline."**
> 8 stages: checkout from Git, run Mockito unit tests (JUnit results show in Jenkins UI), Maven build, npm build, Docker build both images, push to Docker Hub tagged with the build number, SSH into EC2 and run docker-compose up, finally health check the /actuator/health endpoint with 5 retries.

**"How did Terraform reduce manual setup by 60%?"**
> The EC2 userdata.sh script automatically installs Java 17, Docker, Docker Compose, and Jenkins on first boot. Before, each step needed manual SSH commands — now `terraform apply` gives you a fully ready server in one shot.

**"Why Jenkins instead of GitHub Actions?"**
> Jenkins runs on my own EC2 so I have full control over the build environment, no usage limits, and I can configure custom plugins. It also demonstrates real enterprise DevOps skills — credential management, Jenkinsfile syntax, pipeline visualization with Blue Ocean.

**"How does horizontal scalability work here?"**
> The backend is stateless Spring Boot — no session data stored in memory. PostgreSQL is separate. So I can run `docker-compose up --scale backend=3` and spin up 3 containers immediately. A load balancer (like AWS ALB) in front would distribute traffic.
